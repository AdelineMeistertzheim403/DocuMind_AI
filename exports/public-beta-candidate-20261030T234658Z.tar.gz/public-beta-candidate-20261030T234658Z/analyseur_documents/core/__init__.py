"""Fonctions d'analyse textuelle."""
